package com.balazsholczer.introduction;

public class Generics2 {

	public static void add(int num1, int num2) {
		System.out.println("The sum is: " + (num1+num2));
	}
	
	public static void main(String[] args) {
		
		//add2(2.5, 4);
		
	}
}
